<?php
/**
 * Test Generated example of using report_template getrows API
 * Retrieve rows from a report template (optionally providing the instance_id) *
 */
function report_template_getrows_example(){
$params = array(
  'report_id' => 'contact/summary',
  'options' => array(
      'metadata' => array(
          '0' => 'labels',
          '1' => 'title',
        ),
    ),
);

try{
  $result = civicrm_api3('report_template', 'getrows', $params);
}
catch (CiviCRM_API3_Exception $e) {
  // handle error here
  $errorMessage = $e->getMessage();
  $errorCode = $e->getErrorCode();
  $errorData = $e->getExtraParams();
  return array('error' => $errorMessage, 'error_code' => $errorCode, 'error_data' => $errorData);
}

return $result;
}

/**
 * Function returns array of result expected from previous function
 */
function report_template_getrows_expectedresult(){

  $expectedResult = array(
  'is_error' => 0,
  'version' => 3,
  'count' => 2,
  'values' => array(
      '0' => array(
          'civicrm_contact_sort_name' => 'Default Organization',
          'civicrm_contact_id' => '1',
          'civicrm_address_street_address' => '',
          'civicrm_address_city' => '',
          'civicrm_country_name' => '',
        ),
      '1' => array(
          'civicrm_contact_sort_name' => 'Second Domain',
          'civicrm_contact_id' => '2',
          'civicrm_address_street_address' => '15 Main St',
          'civicrm_address_city' => 'Collinsville',
          'civicrm_country_name' => 'United States',
        ),
    ),
  'metadata' => array(
      'title' => 'ERROR: Title is not Set',
      'labels' => array(
          'civicrm_contact_sort_name' => 'Contact Name',
          'civicrm_contact_id' => 'Internal Contact ID',
          'civicrm_address_street_address' => 'Street Address',
          'civicrm_address_city' => 'City',
          'civicrm_country_name' => 'Country',
        ),
    ),
);

  return $expectedResult;
}


/*
* This example has been generated from the API test suite. The test that created it is called
*
* testReportTemplateGetRowsContactSummary and can be found in
* http://svn.civicrm.org/civicrm/trunk/tests/phpunit/CiviTest/api/v3/ReportTemplateTest.php
*
* You can see the outcome of the API tests at
* http://tests.dev.civicrm.org/trunk/results-api_v3
*
* To Learn about the API read
* http://book.civicrm.org/developer/current/techniques/api/
*
* and review the wiki at
* http://wiki.civicrm.org/confluence/display/CRMDOC/CiviCRM+Public+APIs
*
* Read more about testing here
* http://wiki.civicrm.org/confluence/display/CRM/Testing
*
* API Standards documentation:
* http://wiki.civicrm.org/confluence/display/CRM/API+Architecture+Standards
*/
